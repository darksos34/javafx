# Spring Boot Java FX Tutorial

Contributors:

Jordy Hamwijk (Junior Full Stack Developer)

Created on: 24-6-2020<br/>
Last updated on: 24-06-2020

## Why Java fx?

You can build your own scene.<br/>
Develop your own system application.

## Scene Builder

The WYSIWYG drag-n-drop design tool for JavaFx will build an FXML representation of
the UI which can then be loaded by a JavaFx application.  
Scene Builder helps to enforce the MVC pattern, 
keeping business logic out of the code that describes the UI.


## Words explained in human language.
JavaFX = Java "special effects" FX<br/>
Java = object oriented programming<br/>
MVC = Model View Controller<br/>
WYSIWYG = What you see is what you get<br/>
UI = User InterFace<br/>


Finally, MvvmFX is a framework for implementing the Model-View-ViewModel (MVVM) pattern in JavaFX. 
