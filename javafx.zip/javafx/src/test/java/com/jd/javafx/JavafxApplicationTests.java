package com.jd.javafx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavafxApplicationTests {

	@Test
	void contextLoads() {
	}

}
